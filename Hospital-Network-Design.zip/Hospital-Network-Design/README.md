# Hospital Network Design (DCN Project)

## Aim
To design a hospital computer network in Cisco Packet Tracer so that hospital departments can communicate through a structured, segmented network.

## Departments
- Reception
- Doctors
- Emergency
- Laboratory
- Pharmacy
- Administration
- Hospital Records Server

## Planned topology
- 1 Router (2911 or equivalent)
- 1 Main switch (2960)
- 3 departmental access switches (2960)
- 6 PCs
- 1 Server
- Copper straight-through Ethernet links

## IP addressing plan
| VLAN | Department | Network | Gateway |
|---|---|---|---|
| 10 | Reception | 192.168.10.0/24 | 192.168.10.1 |
| 20 | Doctors | 192.168.20.0/24 | 192.168.20.1 |
| 30 | Emergency | 192.168.30.0/24 | 192.168.30.1 |
| 40 | Laboratory | 192.168.40.0/24 | 192.168.40.1 |
| 50 | Pharmacy | 192.168.50.0/24 | 192.168.50.1 |
| 60 | Administration & Server | 192.168.60.0/24 | 192.168.60.1 |

## Important status
This repository template contains documentation and sample reference images only. The actual Cisco Packet Tracer `.pkt` file must be created and saved in Cisco Packet Tracer. Replace the sample images in `screenshots/` with screenshots of your completed simulation, and only mark ping tests as successful after running them.

## Files
- `Hospital_Network.pkt` — create in Cisco Packet Tracer and save here.
- `screenshots/network_topology.png` — screenshot of your finished topology.
- `screenshots/ip_configuration.png` — screenshot(s) of configured IP addresses.
- `screenshots/ping_test.png` — screenshot showing actual ping test results.
- `Project_Report.pdf` — project report.

## How to build
1. Place the router, main switch, three departmental switches, six PCs and one server.
2. Connect router G0/0 to main switch G0/1.
3. Connect the main switch to the three departmental switches using copper straight-through cables.
4. Assign the VLANs and IP addressing plan in the report.
5. Configure router-on-a-stick, switch access ports and trunk links.
6. Configure each PC's IP address, subnet mask `255.255.255.0` and the gateway listed above.
7. Use `ping` between PCs and the server to verify the configuration.
8. Save the simulation as `Hospital_Network.pkt`.

## Note
The IP plan is a design proposal. Match VLANs, ports, trunking and router subinterfaces consistently in Packet Tracer.
